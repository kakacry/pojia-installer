#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
identity-guard.py — 人格文件完整性守卫

用途：给 ~/.workbuddy 下的身份文件（SOUL.md / IDENTITY.md / USER.md / BOOTSTRAP.md）
      建立 SHA256 基线，之后随时校验它们有没有被第三方悄悄改写。

用法：
    python identity-guard.py            # 校验（默认）
    python identity-guard.py verify     # 校验，发现被改动时返回码 1
    python identity-guard.py update     # 重新登记基线（你本人主动改人设后用这个）

注意：update 只应在你本人有意修改人设后执行。若校验发现 CHANGED 而你没改过，
      那就是被外部篡改的信号，先查来源，不要急着 update 覆盖证据。
"""

import hashlib
import json
import os
import sys
import datetime

BASE = os.path.dirname(os.path.abspath(__file__))
FILES = ["SOUL.md", "IDENTITY.md", "USER.md", "BOOTSTRAP.md"]
BASELINE = os.path.join(BASE, "identity.baseline.json")


def digest(path):
    with open(path, "rb") as fp:
        return hashlib.sha256(fp.read()).hexdigest()


def snapshot():
    rec = {}
    for name in FILES:
        path = os.path.join(BASE, name)
        if not os.path.exists(path):
            continue
        st = os.stat(path)
        rec[name] = {
            "sha256": digest(path),
            "size": st.st_size,
            "mtime": datetime.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
        }
    return rec


def cmd_update():
    data = {
        "generated_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "files": snapshot(),
    }
    with open(BASELINE, "w", encoding="utf-8") as fp:
        json.dump(data, fp, ensure_ascii=False, indent=2)
    print("baseline written -> " + BASELINE)
    for name, meta in data["files"].items():
        print("  %-14s %s  %s" % (name, meta["sha256"][:16], meta["mtime"]))


def cmd_verify():
    if not os.path.exists(BASELINE):
        print("no baseline found; run: python identity-guard.py update")
        return 0

    with open(BASELINE, encoding="utf-8") as fp:
        ref = json.load(fp)
    cur = snapshot()

    problems = []
    for name, meta in ref.get("files", {}).items():
        if name not in cur:
            problems.append("MISSING  " + name)
        elif cur[name]["sha256"] != meta["sha256"]:
            problems.append("CHANGED  %s  (%s -> %s)" % (name, meta["mtime"], cur[name]["mtime"]))
        else:
            print("OK       " + name)

    for name in cur:
        if name not in ref.get("files", {}):
            problems.append("NEW      " + name)

    if problems:
        print("")
        for line in problems:
            print(line)
        print("")
        print("baseline generated at: " + ref.get("generated_at", "?"))
        return 1

    print("")
    print("identity intact (baseline: %s)" % ref.get("generated_at", "?"))
    return 0


def main():
    mode = sys.argv[1].lower() if len(sys.argv) > 1 else "verify"
    if mode == "update":
        cmd_update()
        return 0
    if mode in ("verify", "check"):
        return cmd_verify()
    print("usage: identity-guard.py [verify|update]")
    return 2


if __name__ == "__main__":
    sys.exit(main())
