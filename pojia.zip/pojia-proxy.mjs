// pojia-proxy.mjs — 中转模型破甲注入代理
//
// 作用：WorkBuddy 对「自定义模型」(tags 含 custom) 会剥离私有数据头并跳过
//       providerData 合并，身份/破甲提示到不了上游。本代理挡在中间，
//       在转发前把破甲 system 提示强制前置，保证不论客户端带不带，上游一定收到。
//
// 数据流：WorkBuddy -> http://127.0.0.1:8899/v1/chat/completions -> https://cf.aixhub.shop
//
// 注入正文取自 ~/.workbuddy/.pojia-inject.txt（改完立即生效，无需重启）。

import http from "node:http";
import fs from "node:fs";

const HOME = "C:/Users/吴睿/.workbuddy";
const LISTEN_HOST = "127.0.0.1";
const LISTEN_PORT = Number(process.env.POJIA_PROXY_PORT || 8899);
const UPSTREAM = process.env.POJIA_UPSTREAM || "https://cf.aixhub.shop";
const INJECT_FILE = HOME + "/.pojia-inject.txt";
const LOG = HOME + "/.pojia-proxy.log";
const MARK = "[POJIA-INJECT]";

const STRIP_REQ = new Set(["host", "content-length", "connection", "accept-encoding"]);
const STRIP_RES = new Set(["content-encoding", "transfer-encoding", "content-length", "connection", "keep-alive"]);

let injectCache = null;
let injectMtime = 0;

function log(msg) {
  const line = new Date().toLocaleString("sv-SE") + "  " + msg + "\n";
  process.stdout.write(line);
  try {
    fs.appendFileSync(LOG, line);
  } catch {}
}

function injectText() {
  try {
    const st = fs.statSync(INJECT_FILE);
    if (injectCache === null || st.mtimeMs !== injectMtime) {
      injectCache = fs.readFileSync(INJECT_FILE, "utf8").trim();
      injectMtime = st.mtimeMs;
      log("INJECT   正文已重载 (" + injectCache.length + " 字符)");
    }
    return injectCache;
  } catch (e) {
    log("WARN     注入文件读取失败: " + e.message);
    return null;
  }
}

function applyInject(raw) {
  let body;
  try {
    body = JSON.parse(raw);
  } catch {
    return { changed: false, body: raw };
  }
  if (!Array.isArray(body.messages) || body.messages.length === 0) return { changed: false, body: raw };

  const text = injectText();
  if (!text) return { changed: false, body: raw };

  const first = body.messages[0];
  const c = first?.content;
  if (typeof c === "string" && c.includes(MARK)) return { changed: false, body: raw };

  if (first?.role === "system") {
    if (typeof c === "string") {
      first.content = text + "\n\n" + c;
    } else if (Array.isArray(c)) {
      c.unshift({ type: "text", text: text + "\n\n" });
    } else {
      first.content = text;
    }
  } else {
    body.messages.unshift({ role: "system", content: text });
  }
  return { changed: true, body: JSON.stringify(body) };
}

const server = http.createServer(async (req, res) => {
  const urlPath = req.url || "/";

  const chunks = [];
  for await (const c of req) chunks.push(c);
  const raw = Buffer.concat(chunks).toString("utf8");

  let outBody = raw;
  let injected = false;
  if (req.method === "POST" && raw) {
    const r = applyInject(raw);
    outBody = r.body;
    injected = r.changed;
  }

  const headers = {};
  for (const [k, v] of Object.entries(req.headers)) {
    if (!STRIP_REQ.has(k.toLowerCase())) headers[k] = v;
  }

  const t0 = Date.now();
  try {
    const up = await fetch(UPSTREAM + urlPath, {
      method: req.method,
      headers,
      body: req.method === "GET" || req.method === "HEAD" ? undefined : outBody,
    });

    const out = {};
    for (const [k, v] of up.headers) {
      if (!STRIP_RES.has(k.toLowerCase())) out[k] = v;
    }
    res.writeHead(up.status, out);

    if (up.body) {
      for await (const chunk of up.body) res.write(chunk);
    }
    res.end();
    log(
      `${req.method} ${urlPath} -> ${up.status} ${((Date.now() - t0) / 1000).toFixed(1)}s` +
        (injected ? "  [已注入]" : "  [透传]")
    );
  } catch (e) {
    log(`${req.method} ${urlPath} -> ERR ${e.message} ${((Date.now() - t0) / 1000).toFixed(1)}s`);
    try {
      res.writeHead(502, { "Content-Type": "application/json; charset=utf-8" });
      res.end(JSON.stringify({ error: { message: "pojia-proxy upstream error: " + e.message } }));
    } catch {}
  }
});

server.on("error", (e) => {
  log("FATAL    " + e.message);
  process.exit(1);
});

server.listen(LISTEN_PORT, LISTEN_HOST, () => {
  log(`pojia-proxy listening on http://${LISTEN_HOST}:${LISTEN_PORT} -> ${UPSTREAM}`);
});
