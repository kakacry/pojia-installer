﻿# start-pojia.ps1 — 破甲通道一键启动
#
# 用途：开机 / 重启 WorkBuddy 后，把「8899 注入代理」和「guard 守护循环」拉起来。
#       代理负责给自定义模型（中转）强制注入破甲 system 提示；
#       guard 负责守住身份文件、模板、MEMORY 与代理进程本身。
#
# 跑法：右键「使用 PowerShell 运行」，或在终端执行
#       powershell -ExecutionPolicy Bypass -File "$env:USERPROFILE\.workbuddy\start-pojia.ps1"

$Base = "__USERPROFILE__\.workbuddy"

$node = (Get-ChildItem "$Base\binaries\node\versions\*\node.exe" |
         Sort-Object FullName -Descending | Select-Object -First 1).FullName
$py = (Get-ChildItem "$Base\binaries\python\versions\*\python.exe" |
       Sort-Object FullName -Descending | Select-Object -First 1).FullName

if (-not $node) { Write-Host "找不到 node.exe"; exit 1 }
if (-not $py)   { Write-Host "找不到 python.exe"; exit 1 }

# 1) 注入代理（8899）
$probe = Test-NetConnection -ComputerName 127.0.0.1 -Port 8899 -InformationLevel Quiet -WarningAction SilentlyContinue
if (-not $probe) {
    Start-Process -FilePath $node -ArgumentList "`"$Base\pojia-proxy.mjs`"" -WorkingDirectory $Base -WindowStyle Hidden
    Write-Host "[ok] pojia-proxy 已启动 -> 127.0.0.1:8899"
} else {
    Write-Host "[--] pojia-proxy 已在运行"
}

# 2) 守护循环（含代理存活守护）
$guard = Get-CimInstance Win32_Process -Filter "Name='python.exe'" |
         Where-Object { $_.CommandLine -like "*pojiaguard.py*loop*" }
if (-not $guard) {
    Start-Process -FilePath $py -ArgumentList "`"$Base\pojiaguard.py`"", "loop" -WorkingDirectory $Base -WindowStyle Hidden
    Write-Host "[ok] pojiaguard loop 已启动"
} else {
    Write-Host "[--] pojiaguard loop 已在运行"
}

Write-Host ""
Write-Host "破甲通道就绪。自定义模型走 127.0.0.1:8899，注入正文: $Base\.pojia-inject.txt"
Write-Host "日志: $Base\.pojia-proxy.log  /  $Base\.pojia-guard.log"
